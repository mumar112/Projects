// each player chooses a move
// defense goes first (player then comp)
// attacks go second (player then comp)
// health gets minused as attacks land


class Pokemon{
    constructor(hp, atk, def, spA, spD){
        this.hp = hp; 
        this.atk = atk;
        this.def = def;
        this.spA = spA;
        this.spD = spD;
    }
}
 

var trainer = new Pokemon(500,55,30,50,40);
var opponent = new Pokemon (500,65,80,40,40,80);

function getDamage(pokemon){

    return 10 +  (pokemon.atk / pokemon.def) * (pokemon.atk + 2) + Math.floor(Math.random() * 10);
}


//Global variables >>>>>>>>>>>>>>>>>>>>>>>
//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

var trainerMove;
var opponentMove;
var savedopponentMove;
var trainerHP = trainer.hp;
var opponentHP = opponent.hp;


var totRounds = 0;



var res;
var playByPlay = document.getElementById('announcements');
var trainerHPBar = document.getElementById('trainerHPBar');
var opponentHPBar = document.getElementById('opponentHPBar');
var attackButton = document.getElementById('attack');
var playAgain = document.getElementById('playAgain');

function enableButtons() {
	attackButton.disabled = false;

}

function getDamage(pokemon){

    return 10 +  (pokemon.atk / pokemon.def) * (pokemon.atk + 2) + Math.floor(Math.random() * 10);
}

function battle(){
    //trainer attack
    opponent.hp -= getDamage(trainer);

    //check loss
    if(opponent.hp <= 0){
        opponent.hp = 0;
        alert("Your enemies pokemon has fainted!");
        return 0;
    }

    //opponent attack
    trainer.hp -= getDamage(opponent);

    //check loss 
    if(trainer.hp <= 0){
        trainer.hp = 0; 
        alert("Your pokemon has fainted");
        return 0;
    }
}

function healthChange() {
	trainerHPBar.style.width = trainerHP+ "%";
	opponentHPBar.style.width =  opponentHP+ "%";
}



// triggers the fight in the HTML
function fight(){
    battle();
    healthChange();
	gameOver();
}
// adds a round to the round counters
function addRound() {
	totRounds += 1;
}



function gameOver() {
	if (trainerHP === 0 || opponentHP === 0) {
		res = 'gameOver!';
        alert("GAME OVER");
		attackButton.disabled = true;
	}
}
fight();
window.onload=enableButtons();