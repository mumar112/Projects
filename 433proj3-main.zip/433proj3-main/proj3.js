/*
@date: 7/14/2022
@description: CMSC 433 Scripting Languages, Project 3: Pokemon Web Game, user pokemon team
*/

//declare variables that are going to be used throughout the code
var canvas, ctx;
var pokemonHero;
var pokemonEnemy;
var starter;
var background = new Image();
var heroSprite = new Image();
var enemySprite = new Image();
var eliteSprite = new Image();
var array = [];
var userTeam = new team(array);
var enemyTeam = new team(array);
const POKEMON_COUNT = 151;

import data from './pokemon.json' assert { type: "json" };

//Load beginning screen
window.onload = function(){
    background.src = "openingPage.png";
    canvas = document.getElementById("canvas");
    ctx = canvas.getContext("2d");
    ctx.drawImage(background,0,0);
    document.addEventListener('keydown', (event) => {
        switch(event.key){
            case "Enter":
                event.preventDefault();
                chooseStarter();
                break;
        }
    })
}

//Instructions button
export function instructions(){
    alert("Hello Pokemon Trainer!\n\nIf the starting page is blank, please press refresh.\n\n\
    If a button doesn't work the first time, press it again!\n\n\
    1. Press 'Enter' to start and then choose your starting pokemon.\n\
    2. Then, you should end up in the training arena.\n\
    There you can level up your pokemon and find new ones to add to your team!\n\
    Remember, you can only have 6 at a time.\n\
    If you run out of room in your team, but still want a new pokemon, you can swap one of your old pokemon for a new one.\n\
    3. When you feel ready, click 'Fight Elite Four' to battle the Elite Four and prove that your pokemon are the strongest!\n\
    4. You can always return to the training arena by clicking the 'Training Arena' button.");
}


//Choose the starting pokemon => happens when user presses "Enter" on start screen
function chooseStarter(){
    background.src = "starters.png";
    canvas = document.getElementById("canvas");
    ctx = canvas.getContext("2d");
    clear(ctx);
    ctx.drawImage(background,0,0);
    //User selects starter pokemon by pressing 1, 2, or 3. The hero pokemon sprite is set to the
    //sprite sheet retrieved from the database.
    document.addEventListener('keydown', (event) => {
        switch(event.key){
            case "1":
                starter = new pokemon("Squirtle");
                break;
            case "2":
                starter = new pokemon("Bulbasaur");
                break;
            case "3":
                starter = new pokemon("Charmander");
                break;
        }
        heroSprite.src = starter.spriteSheet;
        //add starter to user's pokemon team
        userTeam.addNewPokemon(starter);
        startBattle();
    })
}

//Starts battle in training arena with random pokemon => happens when user presses the "Training Arena"
//button.
export function startBattle(){
    background.src = "trainingArena.png";
    canvas = document.getElementById("canvas");
    ctx = canvas.getContext("2d");
    clear(ctx);
    ctx.drawImage(background,0,0);

    //Generate random number between 1 and 151
    var randomNumber = Math.floor(Math.random() * 151) + 1;
    //Get the pokemon name from the database after looking through it with the index number
    var randPokemon = data[randomNumber]["Pokemon"];
    //var randEnemy = new pokemon(randPokemon);
    //Enemy pokemon declared and set to the randomly selected pokemon
    var randEnemy = new pokemon(randPokemon);
    //the enemy sprite is set to the new enemy's sprite sheet taken from the database
    enemySprite.src = randEnemy.spriteSheet;
    //the user sprite is the first pokemon in their team
    heroSprite.src = userTeam.array[0].spriteSheet;
    //pokemon hero and enemy created and drawn
    pokemonHero = new pokemonAnimate(heroSprite, 100, 350);
    pokemonEnemy = new pokemonAnimate(enemySprite, 600, 170);
    drawBattle();
}

//Starts Elite Four Battle => happens when user presses "Fight Elite Four" button
export function startElite(){
    background.src = "battleArena.png";
    canvas = document.getElementById("canvas");
    ctx = canvas.getContext("2d");
    clear(ctx);
    ctx.drawImage(background,0,0);
    for(i = 0; i < 6; i++){
        //Generate random number between 1 and 151
        var randomNumber = Math.floor(Math.random() * 151) + 1;
        //Get the pokemon name from the database after looking through it with the index number
        var randPokemon = data[randomNumber]["Pokemon"];
        //Enemy pokemon declared and set to the randomly selected pokemon
        var randEnemy = new pokemon(randPokemon);
        enemyTeam.addNewPokemon(randEnemy);
    }
    //the user sprite is the first pokemon in their team
    heroSprite.src = userTeam.array[0].spriteSheet;
    enemySprite.src = enemyTeam.array[0].spriteSheet;

    pokemonHero = new pokemonAnimate(heroSprite, 100, 350);
    pokemonEnemy = new pokemonAnimate(enemySprite, 450, 130);
    drawBattle();
}

//Draws the pokemon in the pokemon battle
function drawBattle(){
    draw(pokemonHero);
    draw(pokemonEnemy);
}

//Pokemon Class => creates Pokemon object
function pokemon(pokeName){
    this.pokeName = pokeName;
    for (var i = 0; i < POKEMON_COUNT; i++){
        if (data[i]["Pokemon"] == pokeName){
            this.type = data[i]["Type I"];
            this.altType = data[i]["Type II"];
            this.maxHP = data[i]["HP"];
            this.att = data[i]["Atk"];
            this.def = data[i]["Def"];
            this.sAtt = data[i]["SpA"];
            this.sDef = data[i]["SpD"];
            this.spd = data[i]["Spe"];
            this.id = data[i]["Per"];
            this.ab1 = data[i]["Ability I"];
            this.ab2 = data[i]["Ability II"];
            this.hidAb = data[i]["Hidden Ability"];
            this.spriteSheet = data[i]["Sprites"];
        }
    }
    this.hp = this.maxHP;
    this.fainted = false;
    
    //Adjusts the pokemon's hit points when it gets damage. Removes the pokemon from rotation if 0 hp
    this.hurtHP = function(num){
        this.hp = this.hp - num;
        if(this.hp <= 0){
            alert("Your pokemon has fainted!");
            this.fainted = true;
        }
    }

    //Heals the pokemon to full health
    this.healHP = function(){
        this.hp = this.maxHp;
        this.fainted = false;
    }
}

//User's Team class => creates a team for the user to use
function team(array){
    this.array = array;

    //Adds a new pokemon to the array
    this.addNewPokemon = function(newPokemon){
        if(!array.length){
            array.push(newPokemon);
        }
        else if(array.length < 6){
            array.push(newPokemon);
        }
        else{
            alert("Your team is full! Please swap a pokemon.");
        }
    }

    //swaps pokemon if the array is already full
    this.swapPokemon = function(newPokemon, oldPokemon){
        if(array.length >= 6){
            for(let i = 0; i < this.array.length; i++){
                if(array[i] == oldPokemon){
                    array[i] = newPokemon;
                    break;
                }
            }
        }
        else{
            alert("You still have room in your team! Please just add a new pokemon.");
        }
    }
}

//Animation Class => creates object to be drawn and animated
function pokemonAnimate(spriteSheet, x, y){
    this.spriteSheet = spriteSheet;
    this.x = x;
    this.y = y;

    this.updateX = function(newX){
        this.x = newX;
    }

    this.updateY = function(newY){
        this.y = newY;
    }

    this.draw = function(ctx){
        ctx.drawImage(this.spriteSheet,
            this.x, this.y);
    }

    //Meant to move pokemon one direction and back to simulate attacking
    this.attack = function(ctx){
        this.x = 300;
        clear();
        drawBattle(ctx);
    }

    //Meant to blink sprite to simulate being hit
    this.gotHit = function(){
        this.x = this.x;
    }

}

//calls the draw() function in the pokemon class
function draw(pokemon){
    pokemon.draw(ctx);
}

//clears the canvas
function clear(ctx){
    ctx.clearRect(0, 0, canvas.width, canvas.height);
}

//calls the attack() function in the pokemon class
function attack(pokemon){
    pokemon.attack(ctx);
}

//calls the gotHit() function in the pokemon class
function gotHit(pokemon){
    pokemon.gotHit();
}
