from excel2json import convert_from_file

convert_from_file('pokemon.xlsx')
