Team 10 Flight Entertainment System
Logan Dumenil
Joseph Mowery
Mohammed Umar

To run the project, you must have Node.js installed on your computer. Once you have Node.js...

1. Open a terminal and ensure you are in the 'Team10-Flight-Entertainment-System' directory. (root of the project)
2. Run ```npm update```; this will install the dependencies defined in package.json.
3. Once the deps are installed, run ```npm start```. This will run the app in your browser.